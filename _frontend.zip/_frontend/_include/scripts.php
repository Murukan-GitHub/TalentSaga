    <div class="modal">
        <div class="modal-dialog">
            <button class="modal-dialog-close">&times;</button>
            <div class="modal-dialog-content"></div>
        </div>
    </div>

    <script>window.myPrefix = '';</script>
    <script src="assets/js/vendor/jquery.min.js"></script>
    <script src="assets/js/vendor/angular.min.js"></script>
    <script src="https://cdn.polyfill.io/v2/polyfill.js?features=default,promise,fetch"></script>
    <script src="assets/js/ts-notification.min.js"></script>
    <script src="assets/js/ts-confirm.min.js"></script>
    <script src="assets/js/vendor/timepicker.min.js"></script>
    <script src="assets/js/vendor/fancybox.min.js"></script>
    <script src="assets/js/vendor/croppie.min.js"></script>
    <script src="assets/js/vendor/selectize.min.js"></script>
    <script src="assets/js/main.min.js?v=1.6.0"></script>
    <script>
        /*
         * tsNotif.show(msg, state) di mana:
         * @param msg {string} - message yang ingin dimunculkan
         * @param state {string} - state yang ingin digunakan. Terdapat 3 state:
         *   - success
         *   - warning
         *   - error
         */
        // tsNotif.show('Lorem ipsum dolor sit amet, consectetur adipisicing elit. Inventore, odio.', 'success')
    </script>
</body>
</html>
