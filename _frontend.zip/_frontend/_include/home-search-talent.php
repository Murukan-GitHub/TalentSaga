<section class="home-section home-section--white">
    <div class="container">
        <h2 class="home-section-heading">Find your perfect talent</h2>

        <div class="find-talent-info-slider default-slider-style">
            <?php for ($i=0; $i < 3; $i++) { ?>
            <div>
                <figure class="find-talent-info-slider-item">
                    <figcaption>Find your perfect talent with simple check talent resume or post a job and see incoming application to your email</figcaption>
                    <img src="assets/img/section-search-talent-img-1.jpg" alt="">
                </figure>
            </div>
            <?php } ?>
        </div>
    </div>
</section>
